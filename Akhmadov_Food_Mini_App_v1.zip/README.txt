# Akhmadov Food — Telegram Mini App v1

Bu birinchi frontend/demo versiya.

Ichida:
- Menyu
- Mahsulot qidirish
- Savatcha
- Mahsulot sonini o‘zgartirish
- Yetkazib berish / olib ketish tanlovi
- Telegram Mini App API bilan boshlang‘ich integratsiya

Hali ulanmagan:
- Haqiqiy backend/database
- Admin panel
- Kuryer paneli
- Click/Payme to‘lovi
- Haqiqiy manzilni saqlash
- Buyurtma statuslarini server orqali kuzatish

Ishlatish:
1. index.html faylini HTTPS hostingga joylashtiring.
2. Olingan HTTPS URL'ni BotFather > Bot Settings > Configure Mini App/Enable Mini App joyiga kiriting.
3. Keyingi bosqichda backend va to‘lov tizimi ulanadi.
